<?php
?>
<!DOCTYPE html>
 <html lang="de">
 <head>
 <title>Webshop</title>
 <meta http-equiv="content-type" content="text/html; charset=utf-8" />
 </head>

 <body>
    <?php
    include 'header.php';
    include 'Navbar.php';
    include 'Startseite.php';
    include 'Footer.php';
    ?>

 </div>

 </body>

 </html>